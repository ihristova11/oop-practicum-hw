#ifndef ELEMENT_TYPE_H
#define ELEMENT_TYPE_H

enum class ElementType {
	FIRE, 
	WATER, 
	AIR, 
	EARTH, 
	PHILOSOPHERS_STONE, 
	COMPOSITE
};

#endif // !ELEMENT_TYPE_H

